﻿// This file is auto genorated from using SubRCRev.exe and template SVN.template
// Build Date: 2013/06/19 00:56:49
// SVN url: https://professionbuddy.googlecode.com/svn/trunk/Professionbuddy

namespace HighVoltz
{
    public partial class Svn
    {
        protected override string RevString
        {
            get
            {
                return "594";
            }
        }
    }
}
